package changemyname;

import static sbcc.Core.*;

import java.io.*;

import static java.lang.System.*;
import static org.apache.commons.lang3.StringUtils.*;

public class Main {

	public static void main(String[] args) throws IOException {

	}

}
